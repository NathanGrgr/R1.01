// fichier Source.cxx

#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>
#include <limits>

#include <ctime>          // time_t, time()
#include <cstdlib>        // random(), srandom()
#include <cstring>        // tolower(), toupper()

using namespace std;

namespace
{

    typedef std::vector <long int>      CVLInt;
    typedef std::vector <long unsigned> CVLUInt;
    typedef std::vector <char>          CVChar;
    typedef std::vector <bool>          CVBool;
    typedef std::vector <string>        CVString;
    typedef std::vector <double>        CVDouble;
    typedef unsigned long               ULong_t;

    class CRand
    {
      public :
        CRand ()
        {
            time_t Date;
            srandom (time (& Date));
        }
    } __Rand;

    int Rand (int Min, int Max)
    {
        if (Min < 0       ) Min = 0;
        if (Max > RAND_MAX) Max = RAND_MAX;
        if (Max <= Min    ) return Min;

        return Min + (random() % (Max - Min + 1));

    } // Rand()

    void GenereTabInt (
        CVLInt & TabInt,
        long unsigned N
    )
    {
        TabInt.resize ((N));
        {
            long long int _BorneInf (0);
            long long int _BorneSup (TabInt.size() - 1);
            for (long long int i = _BorneInf; i <=  _BorneSup; ++i)
            {
                cout << (string ("entrer la ")) << (i) << (string ("eme valeur du tableau : "));
                long int Val;
                cin >> Val;
                {
                    string _S;
                    getline (cin, _S);
                }
                TabInt.at (i) = Val;
            }
        }

    } // GenereTabInt()

    void AfficheTabInt (
        CVLInt TabInt
    )
    {
        {
            long long int _BorneInf (0);
            long long int _BorneSup (TabInt.size() - 1);
            for (long long int i = _BorneInf; i <=  _BorneSup; ++i)
            {
                cout << (TabInt.at (i)) << (string (" "));
            }
        }
        cout << endl;

    } // AfficheTabInt()

    void UtilisationDeAfficheTabIntEtDeGenereTabInt (void)
    {
        long unsigned N;
        cout << (string ("entrer la taille du tableau : "));
        cin >> N;
        {
            string _S;
            getline (cin, _S);
        }
        CVLInt TabInts (0, numeric_limits <long int>::max());
        GenereTabInt (TabInts, N);
        AfficheTabInt (TabInts);

    } // UtilisationDeAfficheTabIntEtDeGenereTabInt()

} // namespace

int main()
{
    try
    {
        UtilisationDeAfficheTabIntEtDeGenereTabInt(); 
    }
    catch (const out_of_range & )
    {
        cout << "\nIndice invalide\n";
        return 1;
    }
   return 0;

} // main()
