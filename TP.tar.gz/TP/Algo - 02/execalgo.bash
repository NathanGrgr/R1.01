#!/bin/bash
# Petit script qui traduit en C++ l'algorithme "algo" passe en parametre,
# genere un fichier "algo".cxx,
# compile "algo".cxx et genere l'executable "algo".exe,
# et execute "algo".exe.
# la commande clean permet un nettoyage du repertoire courrant en supprimant les fichiers d'extensions cxx et exe
#
if [ $# != 1 ]
then
    echo "Usage : $0 algo"
    exit 1
fi
if [ $1 == 'clean' ]
then
    rm *.cxx;
    rm *.exe;
    exit 1
fi

./Analyseur $1 > $1.cxx && g++ -o $1.exe $1.cxx && ./$1.exe;
